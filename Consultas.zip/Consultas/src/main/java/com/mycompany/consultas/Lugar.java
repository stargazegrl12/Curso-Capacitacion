/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultas;

/**
 *
 * @author green
 */
public abstract class Lugar {
        private String nombre;
        private String id;
        
        public Lugar(String nombre,String idCurso){
            System.out.println("Construyendo Lugar");
            this.nombre = nombre;
            this.id = idCurso;
    }
}
