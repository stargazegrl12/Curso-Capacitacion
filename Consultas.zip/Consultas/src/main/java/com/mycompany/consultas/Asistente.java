/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultas;


public class Asistente extends Persona {
    private String idAsistente;
    
    public Asistente(String nombre, String apellidos, int edad) {
        super(nombre, apellidos, edad);
        this.idAsistente = "Unknown";
    }
    
    public String getIdAsistente() {
        return idAsistente;
    }
    
    public void setIdAsistente(String idAsistente) {
        this.idAsistente = idAsistente;
    }
    
}
