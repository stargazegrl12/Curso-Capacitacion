/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.consultas;


/**
 *
 * @author green
 */
public class Consultas {

    public static void main(String[] args) {
        
    }
}
