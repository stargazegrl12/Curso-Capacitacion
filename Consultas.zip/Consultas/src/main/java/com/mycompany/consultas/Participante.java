/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultas;


public class Participante extends Persona {
    private String idParticipante;
    
    public Participante(String nombre, String apellidos, int edad) {
        super(nombre, apellidos, edad);
        this.idParticipante = "Unknown";
    }
    
    public String getIdParticipante() {
        return idParticipante;
    }
    
    public void setIdParticipante(String idParticipante) {
        this.idParticipante = idParticipante;
        
    }
    
}
    
