/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultas;

/**
 *
 * @author green
 */
public class Agenda {
    private String idAgenda;
    private String Fecha;
    private String Hora;
    
    private Lugar lugar;
    private String idCurso;
    private Asistente Asistente;
    private Participante participante;
        

    public Agenda(String Agenda, String fecha, String Hora) {
        this.idAgenda = Agenda;
        this.Hora = Hora;
        this.Fecha = fecha;
    }

    /**
     * @return the idPracticante
     */
    public String getHora() {
        return Hora;
    }


    public void setHora(String Hora) {
        this.Hora = Hora;
    }

    public String getFecha() {
        return Fecha;
    }


    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }
    
    public String getidCurso() {
        return idCurso;
    }

    public void setidCurso(String Curso) {
        this.idCurso = Curso;
    }
    
    public Lugar getLugar() {
        return lugar;
    }


    public void setLugar(Lugar lugar) {
        this.lugar = lugar;
    }
    public Participante getParticipante() {
        return participante;
    }

    public void setParticipante(Participante participante) {
        this.participante = participante;
        }
   
    public Asistente getAsistente() {
        return Asistente;
    }

    public void setAsistente(Asistente Asistente) {
        this.Asistente = Asistente;
    }
}
