/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.consultas;

/**
 *
 * @author green
 */
public abstract class Curso {
    private String nombre;
    private int capacidad;
    private String id;
    
    public Curso(String nombre, int capacidad, String idCurso)
    {
            System.out.println("Construyendo Curso");
            this.nombre = nombre;
            this.capacidad = capacidad;
            this.id = idCurso;
    }
    
}
